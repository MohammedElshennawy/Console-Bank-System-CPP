#pragma once
#pragma warning(disable:4996)
#include <cctype>
#include <vector>
#include <string>
#include "clsString.h"
#include <iostream>

using namespace std;

class clsDate
{

private:

	short _Day = 1;
	short _Month = 1;
	short _Year = 1900;


public:

	clsDate()
	{
		time_t t = time(0);

		tm* now = localtime(&t);

		_Day = now->tm_mday;
		_Month = now->tm_mon + 1;
		_Year = now->tm_year + 1900;
	}

	clsDate(short Day, short Month, short Year)
	{
		_Day = Day;
		_Month = Month;
		_Year = Year;
	}

	clsDate(string DateString)
	{
		vector <string> vDate;

		vDate = SplitString(DateString, "/");
		_Day = stoi(vDate[0]);
		_Month = stoi(vDate[1]);
		_Year = stoi(vDate[2]);
	}

	clsDate(short DateOrderInYear, short Year)
	{
		//This will construct a date by date order in year
		clsDate Date = GetDateFromDayOrderInYear(DateOrderInYear, Year);

		_Day = Date.Day;
		_Month = Date.Month;
		_Year = Date.Year;
	}


	//Property Set
	void SetDay(short Day)
	{
		_Day = Day;
	}

	void SetMonth(short Month)
	{
		_Month = Month;
	}

	void SetYear(short Year)
	{
		_Year = Year;
	}


	//Property Get
	short GetDay()
	{
		return _Day;
	}

	short GetMonth()
	{
		return _Month;
	}

	short GetYear()
	{
		return _Year;
	}


	__declspec(property(get = GetDay, put = SetDay)) short Day;
	__declspec(property(get = GetMonth, put = SetMonth)) short Month;
	__declspec(property(get = GetYear, put = SetYear)) short Year;



	void Print()
	{
		cout << DateToString() << endl;
	}


	static clsDate GetSystemDate()
	{
		//system date
		time_t t = time(0);

		tm* now = localtime(&t);

		short Day, Month, Year;

		Day = now->tm_mday;
		Month = now->tm_mon + 1;
		Year = now->tm_year + 1900;

		return clsDate(Day, Month, Year);

	}

	static string GetSystemDateTimeString()
	{
		//system datetime string
		time_t t = time(0);
		tm* now = localtime(&t);

		short Day, Month, Year, Hour, Minute, Second;

		Year = now->tm_year + 1900;
		Month = now->tm_mon + 1;
		Day = now->tm_mday;
		Hour = now->tm_hour;
		Minute = now->tm_min;
		Second = now->tm_sec;

		return (to_string(Day) + "/" + to_string(Month) + "/" + to_string(Year) + " - "
			+ to_string(Hour) + ":" + to_string(Minute) + ":" + to_string(Second));

	}


	static bool IsValidateDate(clsDate Date)
	{
		if (Date.Day < 1 || Date.Day > 31)
		{
			return false;
		}
		if (Date.Month < 1 || Date.Month > 12)
		{
			return false;
		}
		if (Date.Month == 2)
		{
			if (IsLeapYear(Date.Year))
			{
				if (Date.Day > 29)
				{
					return false;
				}
			}
			else
			{
				if (Date.Day > 28)
				{
					return false;
				}
			}
		}

		short DaysInMonth = NumberOfDaysInMonth(Date.Month, Date.Year);

		if (Date.Day > DaysInMonth)
		{
			return false;
		}

		return true;


		//Other Faster Solution
		/*return (Date.Month <= 12 && Date.Month >= 1) ? (NumberOfDaysInMonth(Date.Month, Date.Year) >= Date.Day ? true : false) : false;*/
	}

	bool IsValidate()
	{
		return IsValidateDate(*this);
	}


	static string DateToString(clsDate Date)
	{
		return to_string(Date._Day) + "/" + to_string(Date._Month) + "/" + to_string(Date._Year);
	}

	string DateToString()
	{
		return DateToString(*this);
	}


	vector <string>  SplitString(string S1, string Delim)
	{
		vector <string> vString;

		short Pos = 0;
		string sWord; // define a string variable

		// use find() function to get the position of the delimiters
		while ((Pos = S1.find(Delim)) != std::string::npos)
		{
			sWord = S1.substr(0, Pos); // store the word

			if (sWord != "")
			{
				vString.push_back(sWord);
			}

			S1.erase(0, Pos + Delim.length()); // erase() until positon and move to next word.    
		}

		if (S1 != "")
		{
			vString.push_back(S1); // it adds last word of the string.
		}

		return vString;

	}


	static bool IsLeapYear(short Year)
	{
		return (Year % 400 == 0) || (Year % 4 == 0 && Year % 100 != 0);

	}

	bool IsLeapYear()
	{
		return IsLeapYear(_Year);
	}


	static short NumberOfDaysInYear(short Year)
	{
		return IsLeapYear(Year) ? 366 : 355;
	}

	short NumberOfDaysInYear()
	{
		return NumberOfDaysInYear(_Year);
	}


	static short NumberOfHoursInYear(short Year)
	{
		return NumberOfDaysInYear(Year) * 24;
	}

	short NumberOfHoursInYear()
	{
		return NumberOfHoursInYear(_Year);
	}


	static int NumberOfMinutesInYear(short Year)
	{
		return NumberOfHoursInYear(Year) * 60;
	}

	int NumberOfMinutesInYear()
	{
		return NumberOfMinutesInYear(_Year);
	}


	static int NumberOfSecondsInYear(short Year)
	{
		return NumberOfMinutesInYear(Year) * 60;
	}

	int NumberOfSecondsInYear()
	{
		return NumberOfSecondsInYear(_Year);
	}


	static short NumberOfDaysInMonth(short Month, short Year)
	{
		if (Month < 1 || Month > 12)
		{
			return 0;
		}

		short NumberOfDays[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };

		return Month == 2 && IsLeapYear(Year) ? 29 : NumberOfDays[Month - 1];


	}

	short NumberOfDaysInMonth()
	{
		return NumberOfDaysInMonth(_Month, _Year);
	}


	static short NumberOfHoursInMonth(short Month, short Year)
	{
		return NumberOfDaysInMonth(Month, Year) * 24;
	}

	short NumberOfHoursInMonth()
	{
		return NumberOfHoursInMonth(_Month, _Year);
	}


	static int NumberOfMinutesInMonth(short Month, short Year)
	{
		return NumberOfHoursInMonth(Month, Year) * 60;
	}

	int NumberOfMinutesInMonth()
	{
		return NumberOfMinutesInMonth(_Month, _Year);
	}


	static int NumberOfSecondsInMonth(short Month, short Year)
	{
		return NumberOfMinutesInMonth(Month, Year) * 60;
	}

	int NumberOfSecondsInMonth()
	{
		return NumberOfSecondsInMonth(_Month, _Year);
	}


	static short DayOfWeekOrder(short Day, short Month, short Year)
	{
		short a = 0, y = 0, m = 0;

		a = (14 - Month) / 12;

		y = Year - a;

		m = Month + (12 * a) - 2;

		return (Day + y + (y / 4) - (y / 100) + (y / 400) + ((31 * m) / 12)) % 7;
	}

	short DayOfWeekOrder()
	{
		return DayOfWeekOrder(_Day, _Month, _Year);
	}


	static string DayFullName(short DayOfWeekOrder)
	{
		string DayNames[7] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

		return DayNames[DayOfWeekOrder];
	}

	static string DayFullName(short Day, short Month, short Year)
	{
		string DayNames[7] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

		return DayNames[DayOfWeekOrder(Day, Month, Year)];
	}

	string DayFullName()
	{
		string DayNames[7] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

		return DayNames[DayOfWeekOrder(Day, Month, Year)];
	}


	static string DayShortName(short DayOfWeekOrder)
	{
		string DayNames[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

		return DayNames[DayOfWeekOrder];
	}

	static string DayShortName(short Day, short Month, short Year)
	{
		string DayNames[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

		return DayNames[DayOfWeekOrder(Day, Month, Year)];
	}

	string DayShortName()
	{
		string DayNames[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

		return DayNames[DayOfWeekOrder(Day, Month, Year)];
	}


	static string MonthShortName(short MonthNumber)
	{
		string Months[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

		return (Months[MonthNumber - 1]);
	}

	string MonthShortName()
	{
		return MonthShortName(_Month);
	}


	static void PrintMonthCalendar(short Month, short Year)
	{
		short NumberOfDays = NumberOfDaysInMonth(Month, Year);

		// Index of the day from 0 to 6
		short current = DayOfWeekOrder(1, Month, Year);

		// Print the current month name
		printf("\n  _______________%s_______________\n\n", MonthShortName(Month).c_str());

		// Print the columns
		printf("  Sun  Mon  Tue  Wed  Thu  Fri  Sat\n");


		// Print appropriate spaces
		short i = 0;

		for (i; i < current; i++)
		{
			printf("     ");
		}

		for (short j = 1; j <= NumberOfDays; j++)
		{
			printf("%5d", j);

			if (++i == 7)
			{
				i = 0;

				printf("\n");
			}
		}

		printf("\n  _________________________________\n");
	}

	void PrintMonthCalendar()
	{
		return PrintMonthCalendar(_Month, _Year);
	}


	static void PrintYearCalendar(short Year)
	{

		printf("\n  _________________________________\n\n");

		printf("           Calendar - %d\n", Year);

		printf("  _________________________________\n");


		for (short i = 1; i <= 12; i++)
		{
			PrintMonthCalendar(i, Year);
		}
	}

	void PrintYearCalendar()
	{
		return PrintYearCalendar(_Year);
	}


	static short DaysFromTheBeginingOfTheYear(short Day, short Month, short Year)
	{
		short TotalDays = 0;

		for (int i = 1; i <= Month - 1; i++)
		{
			TotalDays += NumberOfDaysInMonth(i, Year);
		}

		TotalDays += Day;

		return TotalDays;
	}

	short DaysFromTheBeginingOfTheYear()
	{
		return DaysFromTheBeginingOfTheYear(_Day, _Month, _Year);
	}


	static clsDate GetDateFromDayOrderInYear(short DateOrderInYear, short Year)
	{
		clsDate Date;

		short RemainingDays = DateOrderInYear;

		short MonthDays = 0;

		Date.Year = Year;

		Date.Month = 1;


		while (true)
		{
			MonthDays = NumberOfDaysInMonth(Date.Month, Year);

			if (RemainingDays > MonthDays)
			{
				RemainingDays -= MonthDays;

				Date.Month++;
			}

			else
			{
				Date.Day = RemainingDays;

				break;
			}
		}

		return Date;
	}


	void AddDays(short Days)
	{

		short RemainingDays = DaysFromTheBeginingOfTheYear(_Day, _Month, _Year) + Days;

		short MonthDays = 0;

		_Month = 1;


		while (true)
		{
			MonthDays = NumberOfDaysInMonth(_Month, _Year);

			if (RemainingDays > MonthDays)
			{
				RemainingDays -= MonthDays;

				_Month++;

				if (_Month > 12)
				{
					_Month = 1;

					_Year++;
				}
			}

			else
			{
				_Day = RemainingDays;

				break;
			}
		}

	}

	static bool IsDate1BeforeDate2(clsDate Date1, clsDate Date2)
	{

		return (Date1.Year < Date2.Year) ? true :
			((Date1.Year == Date2.Year) ? (Date1.Month < Date2.Month ? true :
				(Date1.Month == Date2.Month ? Date1.Day < Date2.Day : false)) : false);

		//Other Solution
		/*return (Date1.Year < Date2.Year) ? true :
			(Date1.Year == Date2.Year && Date1.Month < Date2.Month) ? true :
			(Date1.Month == Date2.Month && Date1.Day < Date2.Day) ? true : false;*/

	}

	bool IsDateBeforeDate2(clsDate Date2)
	{
		return IsDate1BeforeDate2(*this, Date2);
	}


	static bool IsDate1EqualDate2(clsDate Date1, clsDate Date2)
	{

		return (Date1.Year == Date2.Year) ? ((Date1.Month == Date2.Month) ? ((Date1.Day == Date2.Day) ? true : false) : false) : false;

		//Other Solution
		/*return (Date1.Year == Date2.Year && Date1.Month == Date2.Month && Date1.Day == Date2.Day) ? true : false;*/

	}

	bool IsDateEqualDate2(clsDate Date2)
	{
		return IsDate1EqualDate2(*this, Date2);
	}


	static bool IsLastDayInMonth(clsDate Date)
	{
		return (NumberOfDaysInMonth(Date.Month, Date.Year) == Date.Day);
	}

	bool IsLastDayInMonth()
	{
		return IsLastDayInMonth(*this);
	}


	static bool IsLastMonthInYear(short Month)
	{
		return (Month == 12);
	}

	bool IsLastMonthInYear()
	{
		return IsLastMonthInYear(_Month);
	}


	static clsDate AddOneDay(clsDate Date)
	{
		if (IsLastDayInMonth(Date))
		{
			if (IsLastMonthInYear(Date.Month))
			{
				Date.Day = 1;
				Date.Month = 1;
				Date.Year++;
			}

			else
			{
				Date.Day = 1;
				Date.Month++;
			}
		}

		else
		{
			Date.Day++;
		}

		return Date;
	}

	void AddOneDay()
	{
		*this = AddOneDay(*this);
	}


	static void SwapDate(clsDate& Date1, clsDate& Date2)
	{
		clsDate TempDate;

		TempDate = Date1;
		Date1 = Date2;
		Date2 = TempDate;
	}


	static int GetDiffrenceInDays(clsDate Date1, clsDate Date2, bool IncludeEndDay = false)
	{
		int Days = 0;
		short SawpFlagValue = 1;

		if (!IsDate1BeforeDate2(Date1, Date2))
		{
			//Swap Dates
			SwapDate(Date1, Date2);
			SawpFlagValue = -1;
		}

		while (IsDate1BeforeDate2(Date1, Date2))
		{
			Days++;

			Date1 = AddOneDay(Date1);
		}
		return IncludeEndDay ? ++Days * SawpFlagValue : Days * SawpFlagValue;

		//Other return 
		//return (Days + IncludeEndDay) * SawpFlagValue;
	}

	int GetDiffrenceInDays(clsDate Date2, bool IncludeEndDay = false)
	{
		return GetDiffrenceInDays(*this, Date2, IncludeEndDay = false);
	}

	static int CalculateMyAgeInDays(clsDate DateOfBirth)
	{
		return GetDiffrenceInDays(DateOfBirth, clsDate::GetSystemDate(), true);
	}


	clsDate IncreaseDateByOneWeek(clsDate& Date)
	{

		for (short i = 0; i < 7; i++)
		{
			Date = AddOneDay(Date);
		}

		return Date;
	}

	void IncreaseDateByOneWeek()
	{
		IncreaseDateByOneWeek(*this);
	}


	clsDate IncreaseDateByXWeeks(clsDate& Date, short Weeks)
	{
		for (short i = 0; i < Weeks; i++)
		{
			Date = IncreaseDateByOneWeek(Date);
		}

		return Date;
	}

	void IncreaseDateByXWeeks(short Weeks)
	{
		IncreaseDateByXWeeks(*this, Weeks);
	}


	clsDate IncreaseDateByOneMonth(clsDate& Date)
	{

		if (Date.Month == 12)
		{
			Date.Month = 1;
			Date.Year++;
		}

		else
		{
			Date.Month++;
		}

		/*last check day in date should not exceed max days in the current month
		example if date is 31/1/2022 increasing one month should not be 31/2/2022, it should
		be 28/2/2022*/

		short NumberOfDaysInCurrentMonth = NumberOfDaysInMonth(Date.Month, Date.Year);

		if (Date.Day > NumberOfDaysInCurrentMonth)
		{
			Date.Day = NumberOfDaysInCurrentMonth;
		}

		return Date;
	}

	void IncreaseDateByOneMonth()
	{
		IncreaseDateByOneMonth(*this);
	}


	clsDate IncreaseDateByXDays(clsDate& Date, int Days)
	{
		for (int i = 0; i < Days; i++)
		{
			Date = AddOneDay(Date);
		}

		return Date;
	}

	void IncreaseDateByXDays(int Days)
	{
		IncreaseDateByXDays(*this, Days);
	}


	clsDate IncreaseDateByXMonths(clsDate& Date, short Months)
	{
		for (short i = 1; i <= Months; i++)
		{
			Date = IncreaseDateByOneMonth(Date);
		}

		return Date;
	}

	void IncreaseDateByXMonths(short Months)
	{
		IncreaseDateByXMonths(*this, Months);
	}


	clsDate IncreaseDateByOneYear(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year++;
			Date.Day--;
		}
		else
		{
			Date.Year++;
		}

		return Date;
	}

	void IncreaseDateByOneYear()
	{
		IncreaseDateByOneYear(*this);
	}


	clsDate IncreaseDateByXYears(clsDate& Date, int Years)
	{
		for (int i = 0; i < Years; i++)
		{
			Date = IncreaseDateByOneYear(Date);
		}

		return Date;
	}

	void IncreaseDateByXYears(int Years)
	{
		IncreaseDateByXYears(*this, Years);
	}


	clsDate IncreaseDateByOneDecade(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year += 10;
			Date.Day--;
		}
		else
		{
			Date.Year += 10;
		}

		return Date;
	}

	void IncreaseDateByOneDecade()
	{
		IncreaseDateByOneDecade(*this);
	}


	clsDate IncreaseDateByXDecades(clsDate& Date, int Decades)
	{
		for (int i = 0; i < Decades; i++)
		{
			Date = IncreaseDateByOneDecade(Date);
		}

		return Date;
	}

	void IncreaseDateByXDecades(short Decades)
	{
		IncreaseDateByXDecades(*this, Decades);
	}


	clsDate IncreaseDateByOneCentury(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year += 100;
			Date.Day--;
		}
		else
		{
			Date.Year += 100;
		}

		return Date;
	}

	void IncreaseDateByOneCentury()
	{
		IncreaseDateByOneCentury(*this);
	}


	clsDate IncreaseDateByOneMillennium(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year += 1000;
			Date.Day--;
		}
		else
		{
			Date.Year += 1000;
		}

		return Date;
	}

	void IncreaseDateByOneMillennium()
	{
		IncreaseDateByOneMillennium(*this);
	}


	clsDate DecreaseDateByOneDay(clsDate& Date)
	{
		if (Date.Day == 1)
		{
			if (Date.Month == 1)
			{
				Date.Day = 31;
				Date.Month = 12;
				Date.Year--;
			}

			else
			{
				Date.Month--;
				Date.Day = NumberOfDaysInMonth(Date.Month, Date.Year);

			}
		}

		else
		{
			Date.Day--;
		}

		return Date;
	}

	void DecreaseDateByOneDay()
	{
		DecreaseDateByOneDay(*this);
	}


	clsDate DecreaseDateByXDays(clsDate& Date, int Days)
	{
		for (int i = 0; i < Days; i++)
		{
			Date = DecreaseDateByOneDay(Date);
		}

		return Date;
	}

	void DecreaseDateByXDays(int Days)
	{
		DecreaseDateByXDays(*this, Days);
	}


	clsDate DecreaseDateByOneWeek(clsDate& Date)
	{

		for (short i = 0; i < 7; i++)
		{
			Date = DecreaseDateByOneDay(Date);
		}

		return Date;
	}

	void DecreaseDateByOneWeek()
	{
		DecreaseDateByOneWeek(*this);
	}


	clsDate DecreaseDateByXWeeks(clsDate& Date, int Weeks)
	{
		for (int i = 0; i < Weeks; i++)
		{
			Date = DecreaseDateByOneWeek(Date);
		}

		return Date;
	}

	void DecreaseDateByXWeeks(int Weeks)
	{
		DecreaseDateByXWeeks(*this, Weeks);
	}


	clsDate DecreaseDateByOneMonth(clsDate& Date)
	{

		if (Date.Month == 1)
		{
			Date.Month == 12;
			Date.Year--;
		}

		else
		{
			Date.Month--;
		}

		/*last check day in date should not exceed max days in the current month
		example if date is 31/1/2022 increasing one month should not be 31/2/2022, it should
		be 28/2/2022*/

		short NumberOfDaysInCurrentMonth = NumberOfDaysInMonth(Date.Month, Date.Year);

		if (Date.Day > NumberOfDaysInCurrentMonth)
		{
			Date.Day = NumberOfDaysInCurrentMonth;
		}

		return Date;
	}

	void DecreaseDateByOneMonth()
	{
		DecreaseDateByOneMonth(*this);
	}


	clsDate DecreaseDateByXMonths(clsDate& Date, int Months)
	{
		for (int i = 0; i < Months; i++)
		{
			Date = DecreaseDateByOneMonth(Date);
		}

		return Date;
	}

	void DecreaseDateByXMonths(int Months)
	{
		DecreaseDateByXMonths(*this, Months);
	}


	clsDate DecreaseDateByOneYear(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year--;
			Date.Day--;
		}
		else
		{
			Date.Year--;
		}

		return Date;
	}

	void DecreaseDateByOneYear()
	{
		DecreaseDateByOneYear(*this);
	}


	clsDate DecreaseDateByXYears(clsDate& Date, int Years)
	{
		for (int i = 0; i < Years; i++)
		{
			Date = DecreaseDateByOneYear(Date);
		}

		return Date;
	}

	void DecreaseDateByXYears(int Years)
	{
		DecreaseDateByXYears(*this, Years);
	}


	clsDate DecreaseDateByOneDecade(clsDate& Date)
	{
		//Period of 10 years
		Date.Year -= 10;

		return Date;
	}

	void DecreaseDateByOneDecade()
	{
		DecreaseDateByOneDecade(*this);
	}


	clsDate DecreaseDateByXDecades(clsDate& Date, int Decades)
	{
		for (int i = 0; i < Decades; i++)
		{
			Date = DecreaseDateByOneDecade(Date);
		}

		return Date;
	}

	void DecreaseDateByXDecades(int Decades)
	{
		DecreaseDateByXDecades(*this, Decades);
	}


	clsDate DecreaseDateByOneCentury(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year -= 100;
			Date.Day--;
		}
		else
		{
			Date.Year -= 100;
		}

		return Date;
	}

	void DecreaseDateByOneCentury()
	{
		DecreaseDateByOneCentury(*this);
	}


	clsDate DecreaseDateByOneMillennium(clsDate& Date)
	{
		if (IsLeapYear(Date.Year) && Date.Month == 2 && Date.Day == 29)
		{
			Date.Year -= 1000;
			Date.Day--;
		}
		else
		{
			Date.Year -= 1000;
		}

		return Date;
	}

	void DecreaseDateByOneMillennium()
	{
		DecreaseDateByOneMillennium(*this);
	}


	static bool IsEndOfWeek(clsDate Date)
	{
		return (DayOfWeekOrder(Date.Day, Date.Month, Date.Year) == 6);
	}

	bool IsEndOfWeek()
	{
		return IsEndOfWeek(*this);
	}


	static bool IsWeekEnd(clsDate Date)
	{
		short DayIndex = DayOfWeekOrder(Date.Day, Date.Month, Date.Year);

		return (DayIndex == 5 || DayIndex == 6);
	}

	bool IsWeekEnd()
	{
		return IsWeekEnd(*this);
	}


	static bool IsBusinessDay(clsDate Date)
	{
		//shorter method is to invert the IsWeekEnd: this will save updating code.
		return !IsWeekEnd(Date);

		//Other Solution
		//return (!DayOrder == 5 || !DayOrder == 6);
	}

	bool IsBusinessDay()
	{
		return IsBusinessDay(*this);
	}


	static short DaysUntilTheEndOfWeek(clsDate Date)
	{
		return (6 - DayOfWeekOrder(Date.Day, Date.Month, Date.Year));
	}

	short DaysUntilTheEndOfWeek()
	{
		return DaysUntilTheEndOfWeek(*this);
	}


	static short DaysUntilTheEndOfMonth(clsDate Date, bool IncludeEndDay = false)
	{
		clsDate EndOfMonthDate;

		EndOfMonthDate.Day = NumberOfDaysInMonth(Date.Month, Date.Year);
		EndOfMonthDate.Month = Date.Month;
		EndOfMonthDate.Year = Date.Year;

		return GetDiffrenceInDays(Date, EndOfMonthDate, IncludeEndDay);

		//OtherSolution
		//return (NumberOfDaysInMonth(Date.Month, Date.Year) - Date.Day + IncludeEndDay);
	}

	short DaysUntilTheEndOfMonth(bool IncludeEndDay = false)
	{
		return DaysUntilTheEndOfMonth(*this, IncludeEndDay);
	}


	static short DaysUntilTheEndOfYear(clsDate Date, bool IncludeEndDay = false)
	{
		clsDate EndOfMonthDate;

		EndOfMonthDate.Day = 31;
		EndOfMonthDate.Month = 12;
		EndOfMonthDate.Year = Date.Year;

		return GetDiffrenceInDays(Date, EndOfMonthDate, IncludeEndDay);

		//Other Solution
		/*return (IsLeapYear(Date.Year) ? 366 - NumberOfDaysFromTheBeginingOfTheYear(Date.Day, Date.Month, Date.Year) + IncludeEndDay :
			365 - NumberOfDaysFromTheBeginingOfTheYear(Date.Day, Date.Month, Date.Year) + IncludeEndDay);*/
	}


	short DaysUntilTheEndOfYear(bool IncludeEndDay = false)
	{
		return DaysUntilTheEndOfYear(*this, IncludeEndDay);
	}


	static short CalculateBusinessDays(clsDate DateFrom, clsDate DateTo)
	{
		short Days = 0;

		while (IsDate1BeforeDate2(DateFrom, DateTo))
		{
			if (IsBusinessDay(DateFrom))
			{
				Days++;
			}

			DateFrom = AddOneDay(DateFrom);
		}
		return Days;
	}


	static short CalculateVacationDays(clsDate DateFrom, clsDate DateTo)
	{
		return CalculateBusinessDays(DateFrom, DateTo);
	}


	static clsDate CalculateVacationReturnDays(clsDate Date, short VacationDays)
	{

		short WeekEndCounter = 0;

		//in case the data  is weekend keep adding one day util you reach business day
		//we get rid of all weekends before the first business day
		while (IsWeekEnd(Date))
		{
			Date = AddOneDay(Date);
		}

		//here we increase the vacation dates to add all weekends to it.

		for (short i = 1; i <= VacationDays + WeekEndCounter; i++)
		{

			if (IsWeekEnd(Date))
				WeekEndCounter++;

			Date = AddOneDay(Date);
		}

		//in case the return date is week end keep adding one day util you reach business day
		while (IsWeekEnd(Date))
		{
			Date = AddOneDay(Date);
		}

		//Other Solution
		/*while (IsWeekEnd(DayOfWeekOrder(Date)))
		{
			Date = IncreaseDateByOneDay(Date);
		}

		for (int i = 1; i <= VacationDays; i++)
		{
			if (!IsBusinessDay(DayOfWeekOrder(Date)))
			{
				Date = IncreaseDateByXDays(Date, 3);
			}
			else
			{
				Date = IncreaseDateByOneDay(Date);
			}
		}

		while (IsWeekEnd(DayOfWeekOrder(Date)))
		{
			Date = IncreaseDateByOneDay(Date);
		}*/


		return Date;
	}


	static bool IsDate1AfterDate2(clsDate Date1, clsDate Date2)
	{
		return (!IsDate1BeforeDate2(Date1, Date2) && !IsDate1EqualDate2(Date1, Date2));
	}

	bool IsDateAfterDate2(clsDate Date2)
	{
		return IsDate1AfterDate2(*this, Date2);
	}


	enum enCompare { Before = -1, Equal = 0, After = 1 };

	static enCompare CompareDates(clsDate Date1, clsDate Date2)
	{
		if (IsDate1BeforeDate2(Date1, Date2))
		{
			return enCompare::Before;
		}
		if (IsDate1EqualDate2(Date1, Date2))
		{
			return enCompare::Equal;
		}
		/*if (IsDate1AfterDate2(Date1, Date2))
		{
			return enCompare::After;
		}*/

		//this is faster
		return enCompare::After;
	}

	enCompare CompareDates(clsDate Date2)
	{
		return CompareDates(*this, Date2);
	}


};



