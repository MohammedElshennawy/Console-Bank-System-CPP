#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsPerson.h"
#include "clsUser.h"
#include "clsInputValidate.h"

using namespace std;

class clsUpdateUserScreen : protected clsScreen
{

private:

    static void _ReadUserInfo(clsUser& User)
    {
        cout << "Enter First Name: ";
        User.FirstName = clsInputValidate::ReadString();

        cout << "Enter Last Name: ";
        User.LastName = clsInputValidate::ReadString();

        cout << "Enter Email: ";
        User.Email = clsInputValidate::ReadString();

        cout << "Enter Phone: ";
        User.Phone = clsInputValidate::ReadString();

        cout << "Enter Password: ";
        User.Password = clsInputValidate::ReadString();

        cout << "Enter Permission: ";
        User.Permissions = _ReadPermissionsToSet();
    }


    static void _PrintUser(clsUser User)
    {
        cout << "\nClient Card:";
        cout << "\n___________________________";
        cout << "\nFirstName   : " << User.FirstName;
        cout << "\nLastName    : " << User.LastName;
        cout << "\nFullName    : " << User.FullName();
        cout << "\nEmail       : " << User.Email;
        cout << "\nPhone       : " << User.Phone;
        cout << "\nUser Name   : " << User.UserName;
        cout << "\nPassword    : " << User.Password;
        cout << "\nPermissions : " << User.Permissions;
        cout << "\n___________________________\n";
    }


    static int _ReadPermissionsToSet()
    {
        int Permissions = 0;

        char Answer = 'n';

        cout << "Do you want to give full acecess (Y|N)?: ";
        cin >> Answer;
        cout << endl;

        if (toupper(Answer) == 'Y')
        {
            return -1;
        }
        else
        {
            cout << "Do you want to give access to: \n";
            cout << "Show Client List (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pListClients;
            }

            cout << "Add New Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pAddNewClient;
            }

            cout << "Delete Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pDeleteClient;
            }

            cout << "Update Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pUpdateClients;
            }

            cout << "Find Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pFindClient;
            }

            cout << "Transactions (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pTranactions;
            }

            cout << "Manage Users (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pManageUsers;
            }
        }

        return Permissions;
    }


public:

    static void ShowUpdateUserScreen()
    {
        _DrawScreenHeader("\tUpdate User Screen");

        string UserName = "";

        cout << "Please Enter UserName: ";
        UserName = clsInputValidate::ReadString();

        while (!clsUser::IsUserExist(UserName))
        {
            cout << "\nUserName is not found, choose another one: ";
            UserName = clsInputValidate::ReadString();
        }

        clsUser User = clsUser::Find(UserName);

        _PrintUser(User);

        cout << "\nAre you sure you want to Update this User [y/n]: ";

        char Answer = 'n';

        cin >> Answer;

        if (Answer == 'y' || Answer == 'Y')
        {

            cout << "\nUpdate User Info.";
            cout << "\n____________________\n";

            _ReadUserInfo(User);

            clsUser::enSaveResults SaveResult;

            SaveResult = User.Save();


            switch (SaveResult)
            {

            case clsUser::enSaveResults::svSucceeded:
            {
                cout << "\nUser Updated Successfully :-)\n";

                _PrintUser(User);

                break;
            }

            case clsUser::enSaveResults::svFaildEmptyObject:

            {
                cout << "\nError User was not saved because it's Empty";

                break;
            }

            }
        }
        else
        {
            cout << "\nError User Was not Updated\n";
        }

    }
};

