#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsClientListScreen.h"
#include "clsAddNewClientScreen.h"
#include "clsDeleteClientScreen.h"
#include "clsUpdateClientScreen.h"
#include "clsFindClientScreen.h"
#include "clsTransactionsScreen.h"
#include "clsManageUsers.h"
#include "clsLoginRegisterScreen.h"
#include "clsCurrencyExchangeMainScreen.h"
#include "Global.h"
#include <iomanip>


using namespace std;

class clsMainScreen : protected clsScreen
{

private:

    enum _enMainMenueOptions {
        eListClients = 1, eAddNewClient = 2, eDeleteClient = 3,
        eUpdateClient = 4, eFindClient = 5, eShowTransactionsMenue = 6,
        eManageUsers = 7, eLoginRegister = 8, eCurrencyExchange = 9, eExit = 10
    };

    static short _ReadMainMenueOption()
    {
        cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 10]? ";

        short Choice = clsInputValidate::ReadShortNumberBetween(1, 10,"Enter Number between 1 to 10? ");

        return Choice;
    }

    static void _GoBackToMainMenue()
    {
        cout << setw(37) << left << "" << "\n\tPress any key to go back to Main Menue...\n";
        system("pause>0");
        ShowMainMenue();
    }

    static void _ShowAllClientsScreen()
    {
        //cout << "\nClient List Screen Will be here...\n";
        clsClientListScreen::ShowClientsList();
    }

    static void _ShowAddNewClientsScreen()
    {
        //cout << "\nAdd New Client Screen Will be here...\n";
        clsAddNewClientScreen::ShowAddNewClientScreen();
    }

    static void _ShowDeleteClientScreen()
    {
        //cout << "\nDelete Client Screen Will be here...\n";
        clsDeleteClientScreen::ShowDeleteClientScreen();
    }

    static void _ShowUpdateClientScreen()
    {
        //cout << "\nUpdate Client Screen Will be here...\n";
        clsUpdateClientScreen::ShowUpdateClientScreen();
    }

    static void _ShowFindClientScreen()
    {
        //cout << "\nFind Client Screen Will be here...\n";
        clsFindClientScreen::ShowFindClientScreen();
    }

    static void _ShowTranscationMenueScreen()
    {
        //cout << "\nTranscation Menue Screen Will be here...\n";
        clsTransactionsScreen::ShowTranscationMenueScreen();
    }

    static void _ShowManageUsersMenueScreen()
    {
        //cout << "\nManage Users Menue Screen Will be here...\n";
        clsManageUsers::ShowManageUsersMenueScreen();
    }

    static void _ShowLoginRegisterScreen()
    {
        //cout << "\nLogin Register Screen Will be here...\n";
        clsLoginRegisterScreen::ShowLoginRegisterScreen();
    }

    static void _ShowCurrencyExchangeMenueScreen()
    {
        //cout << "\nCurrency Exchange Menue Screen Will be here...\n";
        clsCurrencyExchangeMainScreen::ShowCurrencyExchangeMenueScreen();
    }

    /*static void _ShowEndScreen()
    {
        cout << "\nEnd Screen Will be here...\n";
    }*/

    static void _Logout()
    {
        CurrentUser = clsUser::Find("", "");
        //then it will go back to main function.
    }


    static void _PerfromMainMenueOption(_enMainMenueOptions MainMenueOptions)
    {
        switch (MainMenueOptions)
        {
        case _enMainMenueOptions::eListClients:
            system("cls");
            _ShowAllClientsScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eAddNewClient:
            system("cls");
            _ShowAddNewClientsScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eDeleteClient:
            system("cls");
            _ShowDeleteClientScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eUpdateClient:
            system("cls");
            _ShowUpdateClientScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eFindClient:
            system("cls");
            _ShowFindClientScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eShowTransactionsMenue:
            system("cls");
            _ShowTranscationMenueScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eManageUsers:
            system("cls");
            _ShowManageUsersMenueScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eLoginRegister:
            system("cls");
            _ShowLoginRegisterScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eCurrencyExchange:
            system("cls");
            _ShowCurrencyExchangeMenueScreen();
            _GoBackToMainMenue();
            break;

        case _enMainMenueOptions::eExit:
            system("cls");
            _Logout();
            //Login();
            break;
        }
    }


public:

    static void ShowMainMenue()
    {

        system("cls");
        _DrawScreenHeader("\t\tMain Screen");

        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t\t\tMain Menue\n";
        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t[1] Show Client List.\n";
        cout << setw(37) << left << "" << "\t[2] Add New Client.\n";
        cout << setw(37) << left << "" << "\t[3] Delete Client.\n";
        cout << setw(37) << left << "" << "\t[4] Update Client Info.\n";
        cout << setw(37) << left << "" << "\t[5] Find Client.\n";
        cout << setw(37) << left << "" << "\t[6] Transactions.\n";
        cout << setw(37) << left << "" << "\t[7] Manage Users.\n";
        cout << setw(38) << left << "" << "\t[8] Login Register.\n";
        cout << setw(38) << left << "" << "\t[9] Currency Exchange.\n";
        cout << setw(37) << left << "" << "\t[10] Logout.\n";
        cout << setw(37) << left << "" << "===========================================\n";

        _PerfromMainMenueOption((_enMainMenueOptions)_ReadMainMenueOption());
    }
};

