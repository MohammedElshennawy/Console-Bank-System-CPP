#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsCurrency.h"
#include "clsInputValidate.h"
#include<iomanip> // this library stored the std::setw

using namespace std;

class clsCurrencyCalculatorScreen : protected clsScreen
{

private:

    static float _ReadAmount()
    {
        float Amount = 0;

        cout << "\nEnter Amount to Exchange: ";
        Amount = clsInputValidate::ReadFloatNumber();

        return Amount;
    }

    static clsCurrency _GetCurrency(string Message)
    {
        string CurrencyCode;
        
        cout << Message;
        CurrencyCode = clsInputValidate::ReadString();

        while (!clsCurrency::IsCurrencyExist(CurrencyCode))
        {
            cout << "\nCurrency is not found, choose another one: ";

            CurrencyCode = clsInputValidate::ReadString();
        }

        clsCurrency Currency = clsCurrency::FindByCode(CurrencyCode);

        return Currency;
    }
    
    static void _PrintCurrencyCard(clsCurrency Currency, string Title = "\nCurrency Card:")
    {
        cout << "\n" << Title;
        cout << "\n___________________________\n";
        cout << "\nCountry    : " << Currency.Country();
        cout << "\nCode       : " << Currency.CurrencyCode();
        cout << "\nName       : " << Currency.CurrencyName();
        cout << "\nRate(1$) = : " << Currency.Rate();
        cout << "\n___________________________\n";
    }

    static void _PrintCalculationsResults(float Amount, clsCurrency Currency1, clsCurrency Currency2)
    {
        _PrintCurrencyCard(Currency1, "\nCurrency From:");

        float AmountUSD = Currency1.ConvertToUSD(Amount);

        cout << "\n" << Amount << " " << Currency1.CurrencyCode() << " = " << AmountUSD << " USD\n";

        if (Currency2.CurrencyCode() == "USD")
        {
            return;
        }
        else
        {
            cout << "\n\nConverting from USD to:\n";

            _PrintCurrencyCard(Currency2, "Currency To:");

            float AmountInCurrrency2 = Currency1.ConvertToOtherCurrency(Amount, Currency2);

            cout << "\n" << Amount << " " << Currency1.CurrencyCode() << " = " << AmountInCurrrency2 
                << " "  << Currency2.CurrencyCode();

        }
    }

public:

    void static ShowCurrencyCalculatorScreen()
    {
        char Continue = 'Y';

        while (Continue == 'y' || Continue == 'Y')
        {
            system("cls");
            
            _DrawScreenHeader("\tCurrency Calculator Screen");

            clsCurrency CurrencyFrom = _GetCurrency("\nPlease Enter Currency1 Code: ");
            clsCurrency CurrencyTo = _GetCurrency("\nPlease Enter Currency2 Code: ");

            float Amount = _ReadAmount();

            _PrintCalculationsResults(Amount, CurrencyFrom, CurrencyTo);

            cout << "\n\nDo you want to perform another calculation? y/n ? ";

            cin >> Continue;
        }
       
    }
};

