#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsUser.h"
#include "clsInputValidate.h"
#include <iomanip>

using namespace std;

class clsAddNewUserScreen : protected clsScreen
{

private:

    static void _ReadUserInfo(clsUser& User)
    {
        cout << "Enter First Name: ";
        User.FirstName = clsInputValidate::ReadString();

        cout << "Enter Last Name: ";
        User.LastName = clsInputValidate::ReadString();

        cout << "Enter Email: ";
        User.Email = clsInputValidate::ReadString();

        cout << "Enter Phone: ";
        User.Phone = clsInputValidate::ReadString();

        cout << "Enter Password: ";
        User.Password = clsInputValidate::ReadString();

        cout << "Enter Permission: ";
        User.Permissions = _ReadPermissionsToSet();
    }


    static void _PrintUser(clsUser User)
    {
        cout << "\nClient Card:";
        cout << "\n___________________________";
        cout << "\nFirstName   : " << User.FirstName;
        cout << "\nLastName    : " << User.LastName;
        cout << "\nFullName    : " << User.FullName();
        cout << "\nEmail       : " << User.Email;
        cout << "\nPhone       : " << User.Phone;
        cout << "\nUser Name   : " << User.UserName;
        cout << "\nPassword    : " << User.Password;
        cout << "\nPermissions : " << User.Permissions;
        cout << "\n___________________________\n";
    }


    static int _ReadPermissionsToSet()
    {
        int Permissions = 0;

        char Answer = 'n';

        cout << "Do you want to give full acecess (Y|N)?: ";
        cin >> Answer;
        cout << endl;

        if (toupper(Answer) == 'Y')
        {
            return -1;
        }
        else
        {
            cout << "Do you want to give access to: \n";
            cout << "Show Client List (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pListClients;
            }

            cout << "Add New Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pAddNewClient;
            }

            cout << "Delete Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pDeleteClient;
            }

            cout << "Update Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pUpdateClients;
            }

            cout << "Find Client (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pFindClient;
            }

            cout << "Transactions (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pTranactions;
            }

            cout << "Manage Users (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pManageUsers;
            }

            cout << "Show Login Register (Y|N)?: ";
            cin >> Answer;
            cout << endl;

            if (toupper(Answer) == 'Y')
            {
                Permissions += clsUser::enPermissions::pLoginRegister;
            }
        }

        return Permissions;
    }


public:

    static void ShowAddNewUserScreen()
    {
        _DrawScreenHeader("\t  Add User Screen");

        string UserName = "";

        cout << "Please Enter UserName: ";
        UserName = clsInputValidate::ReadString();

        while (clsUser::IsUserExist(UserName))
        {
            cout << "\nUserName Is Already Used, Choose another one: ";
            UserName = clsInputValidate::ReadString();
        }

        clsUser NewUser = clsUser::GetAddNewUserObject(UserName);




        cout << "\nAdd New User Info.";
        cout << "\n____________________\n";

        _ReadUserInfo(NewUser);

        clsUser::enSaveResults SaveResult;

        SaveResult = NewUser.Save();


        switch (SaveResult)
        {

        case clsUser::enSaveResults::svSucceeded:
        {
            cout << "\nUser Addeded Successfully :-)\n";

            _PrintUser(NewUser);

            break;
        }

        case clsUser::enSaveResults::svFaildEmptyObject:

        {
            cout << "\nError User was not saved because it's Empty";

            break;
        }

        case clsUser::enSaveResults::svFaildUserExists:
        {
            cout << "\nError User was not saved because UserName is used!\n";

            break;
        }
        }

    }
       
};

