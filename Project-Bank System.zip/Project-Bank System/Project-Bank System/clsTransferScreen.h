#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsBankClient.h"
#include "clsInputValidate.h"

using namespace std;

class clsTransferScreen : protected clsScreen
{

private:

    static void _PrintClient(clsBankClient Client)
    {
        cout << "\nClient Card:";
        cout << "\n___________________________\n";
        cout << "\nFullName    : " << Client.FullName();
        cout << "\nAcc. Number : " << Client.AccountNumber();
        cout << "\nAcc. Balance: " << Client.AccountBalance;
        cout << "\n___________________________\n";
    }

    static string _ReadAccountNumber(string Massage)
    {
        string AccountNumber = "";

        cout << Massage;

        cin >> AccountNumber;

        return AccountNumber;
    }

    static string _CheckClient(string Massage)
    {
        string AccountNumber = _ReadAccountNumber(Massage);

        while (!clsBankClient::IsClientExist(AccountNumber))
        {
            cout << "\nClient with [" << AccountNumber << "] does not exist.\n";
            AccountNumber = _ReadAccountNumber(Massage);
        }

        return AccountNumber;
    }

    static float ReadAmount(clsBankClient SourceClient)
    {
        float Amount = 0;

        cout << "\nPlease Enter Tansfer Amount? ";

        Amount = clsInputValidate::ReadDblNumber();

        while (Amount > SourceClient.AccountBalance)
        {
            cout << "\nAmount Exceeds the available Balance, Enter another Amount? ";
            Amount = clsInputValidate::ReadDblNumber();
        }

        return Amount;
    }


public:

    static void ShowTransferScreen()
    {
        _DrawScreenHeader("\t  Transfer Screen");

        clsBankClient SourceClient = clsBankClient::Find(_CheckClient("\nPlease Enter Account Number to Tansfer From: "));

        _PrintClient(SourceClient);

        clsBankClient DestinationClient = clsBankClient::Find(_CheckClient("\nPlease Enter Account Number to Tansfer To: "));

        while (SourceClient.AccountNumber() == DestinationClient.AccountNumber())
        {
            cout << "\nYou entered the same account number!!";
            DestinationClient = clsBankClient::Find(_CheckClient("\nPlease Enter Another Account Number to Transfer To: "));   
        }

        _PrintClient(DestinationClient);


        float Amount = ReadAmount(SourceClient);

        cout << "\nAre you sure you want to perform this transaction? ";

        char Answer = 'n';

        cin >> Answer;

        if (Answer == 'y' || Answer == 'Y')
        {
            if (SourceClient.Transfer(Amount, DestinationClient, CurrentUser.UserName))
            {
                cout << "\nTransfer Done Successfully.\n";
            }
            else
            {
                cout << "\nTransfer Faild \n";
            }
        }
        else
        {
            cout << "\nOperation was cancelled.\n";
        }

        _PrintClient(SourceClient);
        _PrintClient(DestinationClient);

    }

};

