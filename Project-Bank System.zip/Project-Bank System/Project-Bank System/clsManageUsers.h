#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsUserListScreen.h"
#include "clsAddNewUserScreen.h"
#include "clsDeleteUserScreen.h"
#include "clsUpdateUserScreen.h"
#include "clsFindUserScreen.h"
#include <iomanip>

using namespace std;

class clsManageUsers : protected clsScreen
{

private:

    enum _enManageUsersMenueOptions {
        eListUsers = 1, eAddNewUsers = 2, eDeleteUsers = 3, eUpdateUsers = 4,
        eFindUsers = 5, eMainMenue = 6
    };


    static short _ReadManageUsersMenueOption()
    {
        cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 6]? ";

        short Choice = clsInputValidate::ReadShortNumberBetween(1, 6, "Enter Number between 1 to 6? ");

        return Choice;
    }

    static void _GoBackToManageUsersMenue()
    {
        cout << "\n\nPlease enter any key to go back to Manage Users Menue.... ";
        system("pause>0");
        ShowManageUsersMenueScreen();
    }

    static void _ShowListUsersScreen()
    {
        //cout << "\nList Users Screen Will Be Here.\n";
        clsListUsersScreen::ShowUsersList();
    }

    static void _ShowAddNewUsersScreen()
    {
        //cout << "\nAdd New Users Screen Will Be Here.\n";
        clsAddNewUserScreen::ShowAddNewUserScreen();
    }

    static void _ShowFindUserScreen()
    {
        //cout << "\nFind Users Screen Will Be Here.\n";
        clsFindUserScreen::ShowFindUserScreen();
    }

    static void _ShowDeleteUserScreen()
    {
        //cout << "\nDelete Users Screen Will Be Here.\n";
        clsDeleteUserScreen::ShowDeleteUserScreen();
    }

    static void _ShowUpdateUserScreen()
    {
        //cout << "\nUpdate Users Screen Will Be Here.\n";
        clsUpdateUserScreen::ShowUpdateUserScreen();
    }

    static void _PerFromManageUsersMenueOption(_enManageUsersMenueOptions ManageUsersMenueOptions)
    {
        switch (ManageUsersMenueOptions)
        {
        case _enManageUsersMenueOptions::eListUsers:
            system("cls");
            _ShowListUsersScreen();
            _GoBackToManageUsersMenue();
            break;

        case _enManageUsersMenueOptions::eAddNewUsers:
            system("cls");
            _ShowAddNewUsersScreen();
            _GoBackToManageUsersMenue();
            break;

        case _enManageUsersMenueOptions::eFindUsers:
            system("cls");
            _ShowFindUserScreen();
            _GoBackToManageUsersMenue();
            break;

        case _enManageUsersMenueOptions::eDeleteUsers:
            system("cls");
            _ShowDeleteUserScreen();
            _GoBackToManageUsersMenue();
            break;

        case _enManageUsersMenueOptions::eUpdateUsers:
            system("cls");
            _ShowUpdateUserScreen();
            _GoBackToManageUsersMenue();
            break;

        case _enManageUsersMenueOptions::eMainMenue:
        {
            //do nothing here the main screen will handle it :-) ;
        }
          
        }
    }


public:

    static void ShowManageUsersMenueScreen()
    {

        system("cls");

        if (!_CheckAccessRights(clsUser::enPermissions::pManageUsers))
        {
            return;// this will exit the function and it will not continue
        }

        _DrawScreenHeader("\t Manage Users Screen");

        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t\t  Manage Users Menue\n";
        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t[1] List Users.\n";
        cout << setw(37) << left << "" << "\t[2] Add New User.\n";
        cout << setw(37) << left << "" << "\t[3] Delete User.\n";
        cout << setw(37) << left << "" << "\t[4] Update User.\n";
        cout << setw(37) << left << "" << "\t[5] Find User.\n";
        cout << setw(37) << left << "" << "\t[6] Main Menue.\n";
        cout << setw(37) << left << "" << "===========================================\n";

         _PerFromManageUsersMenueOption((_enManageUsersMenueOptions)_ReadManageUsersMenueOption());

    }

};

