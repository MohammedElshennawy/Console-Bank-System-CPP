#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsDepositScreen.h"
#include "clsWithdrawScreen.h"
#include "clsTotalBalanceScreen.h"
#include "clsTransferScreen.h"
#include "clsTransferlogListScreen.h"
#include <iomanip>

using namespace std;

class clsTransactionsScreen : protected clsScreen
{

private:

    enum _enTransactionsMenueOptions { eDeposit = 1, eWithdraw = 2, eShowTotalBalance = 3, eShowTransfer = 4,
        eShowTransferLog = 5, eShowMainMenue = 6};


    static short _ReadTransactionsMenueOption()
    {
        cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 6]? ";

        short Choice = clsInputValidate::ReadShortNumberBetween(1, 6, "Enter Number between 1 to 6? ");

        return Choice;
    }


    static void _ShowDepositScreen()
    {
        //cout << "\n Deposit Screen will be here.\n";
        clsDepositScreen::ShowDepositScreen();
    }

    static void _ShowWithdrawScreen()
    {
        //cout << "\n Withdraw Screen will be here.\n";
        clsWithdrawScreen::ShowWithdrawScreen();
    }

    static void _ShowTotalBalanceScreen()
    {
        //cout << "\n Balance Screen will be here.\n";
        clsTotalBalanceScreen::ShowTotalBalances();
    }

    static void _ShowTransferScreen()
    {
        //cout << "\n Transfer Screen will be here.\n";
        clsTransferScreen::ShowTransferScreen();
    }

    static void _ShowTransferLogScreen()
    {
       //cout << "\n Transfer Log List Screen will be here.\n";
        clsTransferlogListScreen::ShowTranferLogScreen();
    }

    static void _GoBackToTransactionMenue()
    {
        cout << "\n\nPress any key to go back to Transactions Menue...";
        system("pause>0");
        ShowTranscationMenueScreen();
    }


    static void _PerFromTransactionMenueOption(_enTransactionsMenueOptions TransactionsMenueOptions)
    {
        switch (TransactionsMenueOptions)
        {
        case _enTransactionsMenueOptions::eDeposit:
            system("cls");
            _ShowDepositScreen();
            _GoBackToTransactionMenue();
            break;

        case _enTransactionsMenueOptions::eWithdraw:
            system("cls");
            _ShowWithdrawScreen();
            _GoBackToTransactionMenue();
            break;

        case _enTransactionsMenueOptions::eShowTotalBalance:
            system("cls");
            _ShowTotalBalanceScreen();
            _GoBackToTransactionMenue();
            break;

        case _enTransactionsMenueOptions::eShowTransfer:
            system("cls");
            _ShowTransferScreen();
            _GoBackToTransactionMenue();
            break;

        case _enTransactionsMenueOptions::eShowTransferLog:
            system("cls");
            _ShowTransferLogScreen();
            _GoBackToTransactionMenue();
            break;

        case _enTransactionsMenueOptions::eShowMainMenue:
        {
            //do nothing here the main screen will handle it :-) ;
        }

        }
    }

public:

    static void ShowTranscationMenueScreen()
    {
        system("cls");

        if (!_CheckAccessRights(clsUser::enPermissions::pTranactions))
        {
            return;// this will exit the function and it will not continue
        }

        _DrawScreenHeader("\t Transcation Screen");

        
        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t\t  Transactions Menue\n";
        cout << setw(37) << left << "" << "===========================================\n";
        cout << setw(37) << left << "" << "\t[1] Deposit.\n";
        cout << setw(37) << left << "" << "\t[2] Withdraw.\n";
        cout << setw(37) << left << "" << "\t[3] Total Balances.\n";
        cout << setw(37) << left << "" << "\t[4] Transfer.\n";
        cout << setw(37) << left << "" << "\t[5] Transfer Log List.\n";
        cout << setw(37) << left << "" << "\t[6] Main Menue.\n";
        cout << setw(37) << left << "" << "===========================================\n";

        _PerFromTransactionMenueOption((_enTransactionsMenueOptions)_ReadTransactionsMenueOption());
    }

};

