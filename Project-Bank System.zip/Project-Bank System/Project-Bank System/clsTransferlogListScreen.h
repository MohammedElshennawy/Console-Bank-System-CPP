#pragma once
#include <iostream>
#include "clsScreen.h"
#include "clsBankClient.h"
#include <iomanip>

using namespace std;

class clsTransferlogListScreen : protected clsScreen
{

private:

    static void _PrintLoginRegisterRecordLine(clsBankClient::stTranferLogRecord TranferLogRecord)
    {

        cout << setw(8) << left << "" << "| " << setw(23) << left << TranferLogRecord.DateTime;
        cout << "| " << setw(8) << left << TranferLogRecord.SourceAccountNumber;
        cout << "| " << setw(8) << left << TranferLogRecord.DistinationAccountNumber;
        cout << "| " << setw(8) << left << TranferLogRecord.Amount;
        cout << "| " << setw(10) << left << TranferLogRecord.srBalanceAfter;
        cout << "| " << setw(10) << left << TranferLogRecord.desBalanceAfter;
        cout << "| " << setw(8) << left << TranferLogRecord.UserName;
    }


public:

    static void ShowTranferLogScreen()
    {

        vector <clsBankClient::stTranferLogRecord> vTranferLogRecord = clsBankClient::GetTranferLogRecordList();

        string Title = "\tTransfer Log List Screen";
        string SubTitle = "\t     (" + to_string(vTranferLogRecord.size()) + ") Record(s).";

        _DrawScreenHeader(Title, SubTitle);

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;

        cout << setw(8) << left << "" << "| " << left << setw(23) << "DateTime";
        cout << "| " << left << setw(8) << "s.Acct";
        cout << "| " << left << setw(8) << "d.Acct";
        cout << "| " << left << setw(8) << "Amount";
        cout << "| " << left << setw(10) << "s.Balance";
        cout << "| " << left << setw(10) << "d.Balance";
        cout << "| " << left << setw(8) << "User";
        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;


        if (vTranferLogRecord.size() == 0)
        {
            cout << "\t\t\t\tNo Logins Available In the System!";
        }
        else
        {
            for (clsBankClient::stTranferLogRecord Record : vTranferLogRecord)
            {

                _PrintLoginRegisterRecordLine(Record);
                cout << endl;
            }
        }

        cout << setw(8) << left << "" << "\n\t_______________________________________________________";
        cout << "_________________________________________\n" << endl;;
    }
};

